<template>
  <router-view class="bg-color font-vazir-fd"/>
</template>

<script setup>
defineOptions({
  name: 'App'
});
</script>
